"""solver components."""
