"""geometry components."""
