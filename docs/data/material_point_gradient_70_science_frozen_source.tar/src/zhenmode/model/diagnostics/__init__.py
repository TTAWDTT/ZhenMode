"""Diagnostics components."""
