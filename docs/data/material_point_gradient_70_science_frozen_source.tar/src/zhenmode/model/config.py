"""Model configuration, physical constants and shared parameter contracts."""

from __future__ import annotations

from dataclasses import dataclass, field
from numbers import Integral, Real

import numpy as np

from zhenmode.model.inputs.sources import _default_bathymetry_file

G_EARTH     = 9.81          # m/s²

RHO_0       = 1025.0        # kg/m³  reference seawater density

ALPHA_T     = 2.0e-4        # 1/°C   thermal expansion coefficient

BETA_S      = 7.6e-4        # 1/psu  haline contraction coefficient

C_P         = 3992.0        # J/(kg·°C) specific heat of seawater
CP0_TEOS10  = 3991.86795711963  # J/(kg K), potential enthalpy / Conservative Temperature

R_EARTH     = 6371.0e3      # m      Earth radius

OMEGA       = 7.2921e-5     # rad/s  Earth angular velocity

@dataclass(frozen=True)
class GlobalGridConfig:
    """Global lat-lon grid specification (finite-difference solver).

    A true global grid: lon spans 0..360 (periodic), lat spans the globe with
    spherical metric factors (dx = R*cos(lat)*dlon varies with latitude).
    Built by inputs.bathymetry.make_global_grid and consumed by solver.factory.
    """
    # ── Horizontal ──
    nx: int = 360                      # zonal grid points (lon, periodic)
    ny: int = 170                      # meridional grid points (lat, ±85°)
    resolution: float = 1.0            # degrees per grid cell
    lat_max: float = 85.0              # poleward lat limit (polar cap below)

    # ── Vertical ──
    z_levels: tuple = (
        0, -5, -15, -30, -50, -75, -100,
        -150, -200, -300, -500, -1000, -2000, -4000,
    )
    nz: int = 14

    @property
    def dlon(self) -> float:
        return self.resolution

    @property
    def dlat(self) -> float:
        return self.resolution

    @property
    def lon(self) -> np.ndarray:
        """Longitude centers [degrees E], 0..360-dlon, periodic."""
        return self.resolution * (0.5 + np.arange(self.nx))

    @property
    def lat(self) -> np.ndarray:
        """Latitude centers [degrees N], symmetric ±, excluding polar cap."""
        return np.linspace(-self.lat_max, self.lat_max, self.ny)

    @property
    def lat_2d(self) -> np.ndarray:
        """2D latitude field (nx, ny) for metric computation."""
        return np.broadcast_to(self.lat[None, :], (self.nx, self.ny))

    @property
    def cos_lat(self) -> np.ndarray:
        """cos(lat) per meridional row (ny,) — spherical metric factor."""
        return np.cos(np.radians(self.lat))

    @property
    def dx_2d(self) -> np.ndarray:
        """Zonal grid spacing [m], varies with latitude: R*cos(lat)*dlon."""
        return R_EARTH * np.radians(self.dlon) * self.cos_lat  # (ny,)

    @property
    def dy(self) -> float:
        """Meridional grid spacing [m] (constant on a lat-lon grid)."""
        return R_EARTH * np.radians(self.dlat)

@dataclass(frozen=True)
class PhysicsConfig:
    """Physics parameterization — hydrostatic primitive equations."""
    # ── Turbulence closure ──
    nu_h: float = 100.0        # m²/s  horizontal eddy viscosity (background)
    nu_v: float = 1.0e-4       # m²/s  vertical eddy viscosity
    kappa_h: float = 100.0     # m²/s  horizontal diffusivity (T, S)
    kappa_v: float = 1.0e-5    # m²/s  vertical diffusivity (T, S)
    # Convective adjustment: enhanced vertical diffusivity applied to
    # statically-unstable columns (heavier over lighter). Standard OGCM
    # remedy for the columnar warm-water accumulation that surface-only
    # restoring cannot remove. Chosen below the explicit RK2 vertical
    # CFL limit for the thin (5 m) top layer at dt=300 s (~0.083 m^2/s).
    kappa_conv: float = 0.05     # m²/s  convective vertical diffusivity

    # ── Scale-selective (biharmonic) viscosity/diffusivity ──
    # Damp grid-scale baroclinic eddy modes (∇⁴, ∝ k⁴) far more than
    # the large-scale flow, killing the eddy-instability blowup while
    # leaving basin-scale physics intact. 0 = disabled (Laplacian only).
    nu_bi: float = 1.0e12      # m⁴/s  biharmonic horizontal viscosity (calibrated 2026-08-21)
    kappa_bi: float = 1.0e12   # m⁴/s  biharmonic horizontal diffusivity

    # ── Gent-McWilliams eddy closure ──
    # Represents unresolved baroclinic eddies as an advective bolus transport
    # that flattens isopycnal slopes, releasing baroclinic available potential
    # energy. Required at coarse (1°) resolution where the baroclinic Rossby
    # radius (~30-50km) is sub-grid; near-inactive at eddy-resolving resolution.
    # 0 = disabled (default; the closure is enabled only on coarse global runs).
    kappa_gm: float = 0.0       # m²/s  GM eddy diffusivity (bolus transport)
    gm_slope_max: float = 0.01  # dimensionless isopycnal-slope limiter
    # ── Redi isopycnal mixing (dissipative counterpart to GM) ──
    # Diffuses tracers ALONG sloped isopycnals. In Griffies skew-flux residual
    # form only the slope-driven terms are applied (the horizontal-gradient
    # part is absorbed into the background kappa_h*lap handled by the linear
    # step). The vertical term -κ_redi|S|²∂zC provides the diapycnal-style
    # APE sink that pure (advective) GM bolus lacks — it is what arrests the
    # w* steepening feedback. Typically κ_redi = κ_gm. 0 = disabled (default).
    kappa_redi: float = 0.0     # m²/s  Redi isopycnal diffusivity; 0 = off

    # TEOS reference variant uses CT and SR≈SA; explicit pressure is required
    # by factory, while the production default retains its original variables.
    # ── Equation of state reference values ──
    T_ref: float = 15.0        # °C    reference temperature
    S_ref: float = 35.0        # psu   reference salinity

    # ── Surface forcing (defaults, can be overridden at runtime) ──
    tau_x: float = 0.0         # N/m²  zonal wind stress
    tau_y: float = 0.0         # N/m²  meridional wind stress
    Q_heat: float = 0.0        # W/m²  surface heat flux

    # ── Bottom friction ──
    cd: float = 2.5e-3         # quadratic drag coefficient
    r_bot: float = 1.0e-3      # linear bottom friction coefficient
    bottom_friction: str = 'linear'  # 'linear' or 'quadratic'
    thermodynamics: str = 'linear'   # appended to preserve existing positional parameters

@dataclass(frozen=True)
class Config:
    """Shared defaults: physics + data paths.

    The horizontal grid is per run (GlobalGridConfig, driven by --resolution /
    --ny / --lat-max in the model CLI), so it is not held here.
    """
    physics: PhysicsConfig = field(default_factory=PhysicsConfig)

    # ── Data paths ──
    # Resolution order: $OCEAN_SOLVER_BATHYMETRY, then <repo>/data/, then
    # <repo>/. Never hard-code a machine-specific absolute path here.
    bathymetry_file: str = field(default_factory=_default_bathymetry_file)

DEFAULT_CONFIG = Config()

def finite_number(name, value, *, positive=False, nonnegative=False):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Real) or not np.isfinite(value):
        raise ValueError(f"{name} must be a finite number")
    if positive and value <= 0.:
        raise ValueError(f"{name} must be positive")
    if nonnegative and value < 0.:
        raise ValueError(f"{name} must be nonnegative")
    return value

def integer_count(name, value, *, minimum=0):
    if isinstance(value, (bool, np.bool_)) or not isinstance(value, Integral) or value < minimum:
        raise ValueError(f"{name} must be an integer >= {minimum}")
    return value
